package com.example.sms.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.example.sms.entity.Assignment;
import com.example.sms.entity.Student;
import com.example.sms.service.AssignmentService;
import com.example.sms.service.NotesService;
import com.example.sms.service.StudentService;

@Controller
@RequestMapping("/student")
public class StudentController {
	@Autowired private StudentService studentService;
	@Autowired private NotesService notesService;
	@Autowired private AssignmentService assignmentService;
	
	@PostMapping("/login")
	public String login(@RequestParam("username") String username, @RequestParam String password, Model model) {
		Student s= studentService.login(username, password);
		if(s!=null)
			return "redirect:/student/dashboard/" +s.getId();
		model.addAttribute("error", "Invalid Login");
		return "login";
	}
	
	@GetMapping("/dashboard/{id}")
	public String dashboard(@PathVariable Long id, Model model) {
	    // ✅ Load student info
	    Student student = studentService.getStudentById(id);
	    model.addAttribute("student", student);

	    // ✅ Load assignments submitted by the student
	    List<Assignment> submittedAssignments = assignmentService.getAssignmentsByStudentId(id);
	    model.addAttribute("assignments", submittedAssignments);

	    // 🧠 Optional: Load assigned work from teacher (if you want students to see upcoming work)
	    List<Assignment> assignedWork = assignmentService.getAllAssignments();
	    model.addAttribute("assignedWork", assignedWork);
	    
	    model.addAttribute("notes", notesService.getAllNotes());

	    return "student/dashboard"; // 🖥️ Loads templates/student/dashboard.html
	}

	
	@PostMapping("/submit-assignment")
	public String submitAssignment(@RequestParam Long studentId, @RequestParam String fileName, @RequestParam("file") MultipartFile file) {
	    Assignment a = new Assignment();
	    a.setFileName(fileName);
	    a.setUploadDate(LocalDate.now());
	    a.setTeacherAssigned(false); 

	    // ✅ This is essential!
	    Student student = studentService.getStudentById(studentId);
	    if (student != null) {
	        a.setStudent(student);
	        assignmentService.saveAssignment(a);
	    }

	    return "redirect:/student/dashboard/" + studentId;
	}


}
