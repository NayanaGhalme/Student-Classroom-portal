package com.example.sms.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.sms.entity.Assignment;
import com.example.sms.entity.Notes;
import com.example.sms.entity.Student;
import com.example.sms.service.AssignmentService;
import com.example.sms.service.NotesService;
import com.example.sms.service.StudentService;

@Controller
@RequestMapping("/teacher")
public class TeacherController {
	@Autowired private StudentService studentService;
	@Autowired private NotesService notesService;
	@Autowired
	private AssignmentService assignmentService;

	
	@GetMapping("/dashboard")
	public String dashboard(Model model) {
		
			List<Student> students = studentService.getAllStudents();
		    List<Notes> notes = notesService.getAllNotes();
		    List<Assignment> assignments = assignmentService.getAllAssignments();
		    model.addAttribute("students", students); // This provides the 'students' list
	        model.addAttribute("notes", notes); 
	        model.addAttribute("assignments", assignments);

		model.addAttribute("students", studentService.getAllStudents());
		model.addAttribute("notes", notesService.getAllNotes());
		model.addAttribute("assignments", assignmentService.getAllAssignments());
		
		return "teacher/dashboard";
	}
	
	@PostMapping("/upload-notes")
	public String uploadNotes(@RequestParam String fileName, @RequestParam String description) {
		Notes n= new Notes(null, fileName, description, LocalDate.now());
		notesService.saveNotes(n);
		return "redirect:/teacher/dashboard";
	}
	
	@PostMapping("/update-attendance")
	public String updateAttendance(@RequestParam Long studentId, @RequestParam int attendance) {
		Student s= studentService.getStudentById(studentId);
		s.setAttendance(attendance);
		studentService.saveStudent(s);
		return "redirect:/teacher/dashboard";
	}
	
	
	@PostMapping("/login")
	public String login(@RequestParam String username, @RequestParam String password,Model model) {
		return "redirect:/teacher/dashboard";
	}
	@PostMapping("/create-assignment")
	public String createAssignment(@RequestParam String fileName, @RequestParam LocalDate dueDate) {
	    Assignment a = new Assignment();
	    a.setFileName(fileName);
	    a.setDueDate(dueDate);
	    a.setTeacherAssigned(true);
	    assignmentService.saveAssignment(a);
	    return "redirect:/teacher/dashboard";
	}


}
