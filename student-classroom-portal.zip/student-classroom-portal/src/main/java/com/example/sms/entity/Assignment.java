package com.example.sms.entity;

import java.time.LocalDate;

import jakarta.persistence.*;

@Entity
public class Assignment {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	private String fileName;
	private LocalDate uploadDate;
	private LocalDate dueDate;
	private boolean teacherAssigned; // true = assigned by teacher, false = submitted by student


	
	@ManyToOne
	private Student student;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public LocalDate getUploadDate() {
		return uploadDate;
	}

	public void setUploadDate(LocalDate localDate) {
		this.uploadDate = localDate;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}
	public LocalDate getDueDate() {
	    return dueDate;
	}

	public void setDueDate(LocalDate dueDate) {
	    this.dueDate = dueDate;
	}

	public boolean isTeacherAssigned() {
		return teacherAssigned;
	}

	public void setTeacherAssigned(boolean teacherAssigned) {
		this.teacherAssigned = teacherAssigned;
	}
	


	
	

}
