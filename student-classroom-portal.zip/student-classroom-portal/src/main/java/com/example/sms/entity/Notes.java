package com.example.sms.entity;

import java.time.LocalDate;

import jakarta.persistence.*;

@Entity
public class Notes {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	private String fileName;
	private String description;
	private LocalDate uploadDate;
	
	public Notes() {
        // Default constructor required by JPA
    }

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public LocalDate getUploadDate() {
		return uploadDate;
	}
	public void setUploadDate(LocalDate uploadDate) {
		this.uploadDate = uploadDate;
	}
	public Notes(Long id, String fileName, String description, LocalDate uploadDate) {
		this.id = id;
		this.fileName = fileName;
		this.description = description;
		this.uploadDate = uploadDate;
	}
	

}
