package com.example.sms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.sms.entity.Assignment;

public interface AssignmentRepository extends JpaRepository<Assignment, Long>{
	List<Assignment> findByStudentId(Long studentId);
	List<Assignment> findAllByOrderByUploadDateDesc();
	List<Assignment> findByTeacherAssignedTrue();
	List<Assignment> findByStudentIdAndTeacherAssignedFalse(Long studentId);


}
