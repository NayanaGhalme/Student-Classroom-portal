package com.example.sms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.sms.entity.Notes;

public interface NotesRepository extends JpaRepository<Notes, Long> {
	// You can add custom query methods here if needed

}
