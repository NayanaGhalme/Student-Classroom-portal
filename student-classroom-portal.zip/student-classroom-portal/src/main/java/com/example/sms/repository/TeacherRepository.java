package com.example.sms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.sms.entity.Teacher;

public interface TeacherRepository extends JpaRepository<Teacher, Long> {
	Teacher findByUsername(String username);

}
