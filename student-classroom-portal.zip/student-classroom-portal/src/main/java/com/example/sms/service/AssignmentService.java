package com.example.sms.service;

import java.util.List;

import com.example.sms.entity.Assignment;

public interface AssignmentService {
		Assignment saveAssignment(Assignment assignment);
		List<Assignment> getAssignmentsByStudentId(Long studentId);
		List<Assignment> getAllAssignments();
		List<Assignment> getAssignedWork();

		List<Assignment> getStudentSubmissions(Long studentId);

		
		


}
