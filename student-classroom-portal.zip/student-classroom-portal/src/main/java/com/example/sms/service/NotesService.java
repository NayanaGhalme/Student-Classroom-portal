package com.example.sms.service;

import java.util.List;

import com.example.sms.entity.Notes;

public interface NotesService {
	Notes saveNotes(Notes notes);
	List <Notes> getAllNotes();

}
