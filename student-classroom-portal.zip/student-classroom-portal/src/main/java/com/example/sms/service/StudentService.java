package com.example.sms.service;

import java.util.List;

import com.example.sms.entity.Student;

public interface StudentService {
	Student saveStudent(Student student);
	Student getStudentById(Long id);
	
	List<Student> getAllStudents();
	Student login(String email, String password);

}
