package com.example.sms.service;

import com.example.sms.entity.Teacher;

public interface TeacherService {
	Teacher login(String username, String password);

}
