package com.example.sms.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.sms.entity.Assignment;
import com.example.sms.repository.AssignmentRepository;
import com.example.sms.service.AssignmentService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AssignmentServiceImpl implements AssignmentService{
	
	@Autowired
	private AssignmentRepository assignmentRepository;

	@Override
	public Assignment saveAssignment(Assignment assignment) {
		return assignmentRepository.save(assignment);
	}

	@Override
	public List<Assignment> getAssignmentsByStudentId(Long studentId) {
		return assignmentRepository.findByStudentId(studentId);
	}
	@Override
	public List<Assignment> getAllAssignments() {
	    return assignmentRepository.findAllByOrderByUploadDateDesc();
	}
	@Override
	public List<Assignment> getAssignedWork() {
	    return assignmentRepository.findByTeacherAssignedTrue();
	}
	@Override
	public List<Assignment> getStudentSubmissions(Long studentId) {
	    return assignmentRepository.findByStudentIdAndTeacherAssignedFalse(studentId);
	}
	


}
