package com.example.sms.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.sms.entity.Student;
import com.example.sms.repository.StudentRepository;
import com.example.sms.service.StudentService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class StudentServiceImpl implements StudentService{
	
	private final StudentRepository studentRepository;

    @Autowired
    public StudentServiceImpl(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }
		
		@Override
		public Student saveStudent(Student student) {
			return studentRepository.save(student);
		}

		@Override
		public Student getStudentById(Long id) {
			// TODO Auto-generated method stub
			return studentRepository.findById(id).orElse(null);
		}

		@Override
		public List<Student> getAllStudents() {
			// TODO Auto-generated method stub
			return studentRepository.findAll();
		}

		@Override
		public Student login(String email, String password) {
			// TODO Auto-generated method stub
			Student s= studentRepository.findByEmail(email);
			return (s!= null && s.getPassword().equals(password)) ? s : null;
		}

}
