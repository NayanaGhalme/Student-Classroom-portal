package com.spring.ex.Student_Management_System;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@ComponentScan(basePackages = {
	    "com.example.sms.controller",
	    "com.example.sms.service",
	    "com.example.sms.serviceimpl"
	})
@EnableJpaRepositories(basePackages = "com.example.sms.repository")
@EntityScan(basePackages = "com.example.sms.entity")
public class Student_Management_SystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(Student_Management_SystemApplication .class, args);

	}

}
